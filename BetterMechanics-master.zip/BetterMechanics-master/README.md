BetterMechanics
===============
A lightweight replacement for CraftBookMechanisms